<?php
echo "Current server date/time: ".date("d-m-Y H:i:s",time());
phpinfo();
?>